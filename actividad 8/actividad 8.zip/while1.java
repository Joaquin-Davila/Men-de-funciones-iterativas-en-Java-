public class while1 {
    public static void main(String[] args) {
        String opcion = "0";
        while (!opcion.equals("6")) {
            System.out.println("\033[H\033[2J");
            System.out.flush();
            System.out.println(
                    "Proyecto Final de la materia Fundamentos de Computación 1.\nDesarrolladem ,o por Joaquín Davila.\nVersion 1.0");
            System.out.println("Menu Principal");
            System.out.println("1. if - Triangulos\n2. for - Padovan\n3. while - \n4. do -");
            System.out.println("5. Arreglos - ");
            System.out.println("6. bye bye");
            opcion = System.console().readLine("¿Qué quieres hacer? ");
            switch (opcion) {
                case "1":
                    System.out.println("\033[H\033[2J");
                    System.out.flush();
                    System.out.println("Triangulos");
                    triangulos();
                    break;

                case "2":
                    System.out.println("\033[H\033[2J");
                    System.out.flush();
                    padovan();
                    break;

                case "3":
                    System.out.println("\033[H\033[2J");
                    System.out.flush();
                    System.out.println("while El profe no sabe");
                    System.console().readLine("Presiones Enter para continuar");
                    break;

                case "4":
                    System.out.println("\033[H\033[2J");
                    System.out.flush();
                    System.out.println("do El profe no sabe");
                    System.console().readLine("Presiones Enter para continuar");
                    break;

                case "5":
                    System.out.println("\033[H\033[2J");
                    System.out.flush();
                    System.out.println("arreglos El profe no sabe");
                    System.console().readLine("Presiones Enter para continuar");
                    break;

                case "6":
                    System.out.println("\033[H\033[2J");
                    System.out.flush();
                    System.out.println("Gracias por usar el sistema");
                    break;

                default:
                    System.out.println("\033[H\033[2J");
                    System.out.flush();
                    System.out.println(opcion + " No disponible (Opciones del 1 al 6)");
                    System.console().readLine("Presiones Enter para continuar");
                    break;
            }
        }
    }

    static void padovan(){
        String opc = "s";
        while (opc.equals("s")) {
            System.out.println("\033[H\033[2J");
            System.out.flush();
            System.out.println("Sistema para encontrar la secuencia de Padovan.\nDesarrollado por Joaquín Dávila.\nVersion 1.0.");
            int limite = Integer.parseInt(System.console().readLine("Ingrese el limite de la secuencia de Padovan: "));
            int p1 = 1, p2 = 1, p3 = 1, pn = 0;
            System.out.print("\nSecuencia de Padovan = ");
            for (;p1 <= limite;) {
                System.out.print(p1);
                pn = p1 + p2;
                p1 = p2;
                p2 = p3; 
                p3 = pn;
                    if (p1 > limite) {
                        System.out.print(".");
                    } else if (p1 == limite) {
                        System.out.print(", ");
                    } else {
                        System.out.print(", ");
                    }
            }
            opc = System.console().readLine("\n\nOtra vez s/n? ");
        }
    }

    static void triangulos(){
        String opc = "s";
            while (opc.equals("s")) {
                System.out.println("Sistema para determinar si tres longitudes cumplen con ser un triangulo y su tipo");
                System.out.println("Version 1.0\nDesarrollado por Joaquín Dávila Arenas");
                float lado1 = Float.parseFloat(System.console().readLine("Ingrese el lado 1: "));
                if (lado1 > 0) {
                    float lado2 = Float.parseFloat(System.console().readLine("Ingrese el lado 2: "));
                    if (lado2 > 0) {
                        float lado3 = Float.parseFloat(System.console().readLine("Ingrese el lado 3: "));
                        if (lado3 > 0) {
                            System.out.println("Todas las medidas son positivas.");
                            float mayor = lado1;
    
                            if (mayor < lado2) {
                                mayor = lado2;
                            }
    
                            if (mayor < lado3) {
                                mayor = lado3;
                            }
                            System.out.println("El lado mayor es " + mayor);
    
                            if (mayor <= lado1 + lado2 + lado3 - mayor) {
                                System.out.println("Si soy un triángulo!");
                                System.out.println(
                                        "Porque se cumple que " + mayor + " <= " + (lado1 + lado2 + lado3 - mayor));
                                if (lado1 == lado2 && lado2 == lado3) {
                                    System.out.println("Equilatero ");
                                } else if (lado1 != lado2 && lado2 != lado3 && lado1 != lado3) {
                                    System.out.println("Escaleno");
                                } else {
                                    System.out.println("Isoceles");
                                }
                            } else {
                                System.out.println("Con esas medidas no es posible formar un triángulo.");
                                System.out.println(
                                        "Porque no se cumple que " + mayor + " <= " + (lado1 + lado2 + lado3 - mayor));
                            }
                        } else {
                            System.out.println("Error en la longitud del lado 3.");
                        }
                    } else {
                        System.out.println("Error en la longitud del lado 2.");
                    }
                } else {
                    System.out.println("Error en la longitud.");
                }
                opc = System.console().readLine("Otra vez s/n? ");
            }
    }
}


